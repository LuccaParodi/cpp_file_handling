#ifndef FUNCIONES_GLOBALES_H_INCLUDED
#define FUNCIONES_GLOBALES_H_INCLUDED
void cargarMusico() {
    musicos obj;
    FILE* pCli;
    pCli = fopen("musicos.dat", "ab");
    if (pCli == NULL) {
        std::cout << "NO SE PUDO CREAR EL ARCHIVO" << std::endl;
        return;
    }

    obj.cargarmusicos();

    fwrite(&obj, sizeof(musicos), 1, pCli);
    fclose(pCli);

    std::cout << "M�sico agregado correctamente." << std::endl;
}

void mostrarMusicos(){
musicos obj;
  FILE * pCli;
  pCli = fopen("musicos.dat", "rb");
  if (pCli == NULL) {
    std::cout << "NO SE PUDO LEER EL ARCHIVO" << std::endl;
    return;
  }

  while (fread( & obj, sizeof obj, 1, pCli) == 1) {
    obj.mostrarmusicos();
    std::cout << std::endl;
  }
  fclose(pCli);
  system("pause");
  system("cls");
}

int buscarmusico (int d){
musicos obj;
int pos=0;
FILE *pCli;
pCli=fopen("musicos.dat","rb");
if (pCli==NULL){std::cout<<"no se puede leer archivos";return -2;}
while(fread(&obj,sizeof obj,1,pCli)==1){
    if(obj.getDNI()==d){
        fclose(pCli);
        return pos;
    }
    pos++;
}
fclose(pCli);
return -1;
}

musicos leermusicos(int p){
musicos obj;
obj.setDNI(-2);
if(p<0){obj.setDNI(-3);return obj;}
FILE *ar;
ar=fopen("musicos.dat","rb");
if (ar==NULL){return obj;}
fseek(ar,sizeof obj *p, 0);
int aux=fread(&obj, sizeof obj,1,ar);
fclose(ar);
if(aux==0){obj.setDNI(-1);}
return obj;
}

void buscarPorDNI() {
  musicos obj;
  bool encontro = false;
  FILE * pCli;
  pCli = fopen("musicos.dat", "rb");
  if (pCli == NULL) {
    std::cout << "NO SE PUDO ABRIR EL ARCHIVO" << std::endl;
    return;
  }
  int DNI;
  std::cout << "INGRESE EL DNI A BUSCAR: ";
  std::cin >> DNI;

  while (fread( & obj, sizeof obj, 1, pCli) == 1) {
        if (obj.getESTADO()==true){
    if (DNI == obj.getDNI()){
      obj.mostrarmusicos();
      std::cout << std::endl;
      encontro = true;
    }
  }
  }
  if (encontro == false) {
    std::cout << "NO SE ENCONTRO MUSICO CON ESE DNI" << std::endl;
  }
  fclose(pCli);
    system("pause");
  system("cls");
}

bool bajalogica(){
 musicos obj;
  int DNI;
  std::cout<<"ingrese el DNI que quiere dar de baja: ";
  std::cin>>DNI;
 int pos=buscarmusico(DNI);
 obj=leermusicos(pos);
 obj.setESTADO(false);
 FILE *archivo;
 archivo=fopen("musicos.dat","rb+");
 fseek(archivo,sizeof obj *pos, 0);
 bool aux= fwrite(&obj,sizeof obj, 1, archivo);
 fclose(archivo);
 return aux;
   system("pause");
  system("cls");
}

void listarMusicos(){
musicos obj;
  FILE * pCli;
  pCli = fopen("musicos.dat", "rb");
  if (pCli == NULL) {
    std::cout << "NO SE PUDO LEER EL ARCHIVO" << std::endl;
    return;
  }

  while (fread( & obj, sizeof obj, 1, pCli) == 1) {
        if(obj.getESTADO()!=false){
    obj.mostrarmusicos();
    std::cout << std::endl;
  }
  }
  fclose(pCli);
system("pause");
  system("cls");
}

void modificarFecha(){
musicos obj;
  int DNI;
  bool aux;
  std::cout<<"ingrese el DNI que quiere modificar la fecha: ";
  std::cin>>DNI;
 int pos=buscarmusico(DNI);
 obj=leermusicos(pos);
std::cout<<"ingrese la nueva fecha: "<<std::endl;
Fecha nueva;
nueva.Cargar();
obj.setInscripcion(nueva);
 FILE *archivo;
 archivo=fopen("musicos.dat","rb+");
 fseek(archivo,sizeof obj *pos, 0);
 aux=fwrite(&obj,sizeof obj, 1, archivo);
 fclose(archivo);
  system("pause");
  system("cls");

}

/////////////////////////////////////////////////////////////////////////////////////////////////////////

generos leergeneros(int p){
generos obj;
obj.setID(-2);
if(p<0){obj.setID(-3);return obj;}
FILE *ar;
ar=fopen("generos.dat","rb");
if (ar==NULL){return obj;}
fseek(ar,sizeof obj *p, 0);
int aux=fread(&obj, sizeof obj,1,ar);
fclose(ar);
if(aux==0){obj.setID(-1);}
return obj;
}

int buscargeneros (int d){
generos obj;
int pos=0;
FILE *pCli;
pCli=fopen("generos.dat","rb");
if (pCli==NULL){std::cout<<"no se puede leer archivos";return -2;}
while(fread(&obj,sizeof obj,1,pCli)==1){
    if(obj.getID()==d){
        fclose(pCli);
        return pos;
    }
    pos++;
}
fclose(pCli);
return -1;
}

void cargarGenero() {
  generos obj;
  FILE * pCli;
  pCli = fopen("generos.dat", "ab");
  if (pCli == NULL) {
    std::cout << "NO SE PUDO CREAR EL ARCHIVO" << std::endl;
  }
  obj.agregarGenero();
  fwrite( & obj, sizeof(generos), 1, pCli);
  fclose(pCli);
  system("pause");
  system("cls");
}

void listarGeneros(){
generos obj;
  FILE * pCli;
  pCli = fopen("generos.dat", "rb");
  if (pCli == NULL) {
    std::cout << "NO SE PUDO LEER EL ARCHIVO" << std::endl;
    return;
  }

  while (fread( & obj, sizeof obj, 1, pCli) == 1) {
        if(obj.getESTADO()!=false){
    obj.mostrarGeneros();
    std::cout << std::endl;
  }
  }
  fclose(pCli);
  system("pause");
  system("cls");
}

void buscarGeneroPorID() {
  generos obj;
  bool encontro = false;
  FILE * pCli;
  pCli = fopen("generos.dat", "rb");
  if (pCli == NULL) {
    std::cout << "NO SE PUDO ABRIR EL ARCHIVO" << std::endl;
    return;
  }
  int ID;
  std::cout << "INGRESE EL ID A BUSCAR: ";
  std::cin >> ID;

  while (fread( & obj, sizeof obj, 1, pCli) == 1) {
        if (obj.getESTADO()==true){
    if (ID == obj.getID()){
      obj.mostrarGeneros();
      std::cout << std::endl;
      encontro = true;
    }
  }
  }
  if (encontro == false) {
    std::cout << "NO SE ENCONTRO UN GENERO CON ESA ID" << std::endl;
  }
  fclose(pCli);
  system("pause");
  system("cls");
}

void modificarAnio(){
generos obj;
  int ID;
  bool aux;
  std::cout<<"ingrese la ID de la que quiere modificar su anio: ";
  std::cin>>ID;
 int pos=buscargeneros(ID);
 obj=leergeneros(pos);
 int anio;
 std::cout<<"ingrese el nuevo anio"<<std::endl;
 std::cin>>anio;
obj.setAnio(anio);
 FILE *archivo;
 archivo=fopen("generos.dat","rb+");
 fseek(archivo,sizeof obj *pos, 0);
 aux=fwrite(&obj,sizeof obj, 1, archivo);
 fclose(archivo);
system("pause");
system("cls");
return;
}

bool bajageneros(){
 generos obj;
  int ID;
  std::cout<<"ingrese la ID del genero que quiere dar de baja: ";
  std::cin>>ID;
 int pos=buscargeneros(ID);
 obj=leergeneros(pos);
 obj.setESTADO(false);
 FILE *archivo;
 archivo=fopen("generos.dat","rb+");
 fseek(archivo,sizeof obj *pos, 0);
 bool aux= fwrite(&obj,sizeof obj, 1, archivo);
 fclose(archivo);
 return aux;
 system("pause");
 system("cls");
}


//////////////////////////////////////////////////////
void AgregarInstrumento(){
  Instrumentos obj;
  FILE * pCli;
  pCli = fopen("instrumentos.dat", "ab");
  if (pCli == NULL) {
    std::cout << "NO SE PUDO CREAR EL ARCHIVO" << std::endl;
  }
  obj.AgregarInstrumento();
  fwrite( & obj, sizeof(Instrumentos), 1, pCli);
  fclose(pCli);
  system("pause");
  system("cls");
}

void ListarInstrumentosPorId(){
 Instrumentos obj;
  bool encontro = false;
  FILE * pCli;
  pCli = fopen("instrumentos.dat", "rb");
  if (pCli == NULL) {
    std::cout << "NO SE PUDO ABRIR EL ARCHIVO" << std::endl;
    return;
  }
  int ID;
  std::cout << "INGRESE EL ID A BUSCAR: ";
  std::cin >> ID;

  while (fread( & obj, sizeof obj, 1, pCli) == 1) {
        if (obj.getESTADO()==true){
    if (ID == obj.getID()){
      obj.MostrarInstrumentos();
      std::cout << std::endl;
      encontro = true;
    }
  }
  }
  if (encontro == false) {
    std::cout << "NO SE ENCONTRO ESE INSTRUMENTO" << std::endl;
  }
  fclose(pCli);
    system("pause");
  system("cls");
}

void ListarTodosLosInstrumentos(){
Instrumentos obj;
  FILE * pCli;
  pCli = fopen("instrumentos.dat", "rb");
  if (pCli == NULL) {
    std::cout << "NO SE PUDO LEER EL ARCHIVO" << std::endl;
    return;
  }

  while (fread( & obj, sizeof obj, 1, pCli) == 1) {
        if(obj.getESTADO()!=false){
    obj.MostrarInstrumentos();
    std::cout << std::endl;
  }
  }
  fclose(pCli);
system("pause");
  system("cls");
}

int buscarInstrumento (int d){
Instrumentos obj;
int pos=0;
FILE *pCli;
pCli=fopen("instrumentos.dat","rb");
if (pCli==NULL){std::cout<<"no se puede leer archivos";return -2;}
while(fread(&obj,sizeof obj,1,pCli)==1){
    if(obj.getID()==d){
        fclose(pCli);
        return pos;
    }
    pos++;
}
fclose(pCli);
return -1;
}

Instrumentos leerInstrumentos (int p){
Instrumentos obj;
obj.setID(-2);
if(p<0){obj.setID(-3);return obj;}
FILE *ar;
ar=fopen("instrumentos.dat","rb");
if (ar==NULL){return obj;}
fseek(ar,sizeof obj *p, 0);
int aux=fread(&obj, sizeof obj,1,ar);
fclose(ar);
if(aux==0){obj.setID(-1);}
return obj;
}

void ModificarNombre(){
    Instrumentos obj;
  int ID;
  bool aux;
  std::cout<<"ingrese la ID del instrumento cuyo nombre desea modificar: ";
  std::cin>>ID;
 int pos=buscarInstrumento(ID);
 obj=leerInstrumentos(pos);
 char nombre[30];
 std::cout<<"ingrese el nuevo nombre"<<std::endl;
 std::cin>>nombre;
obj.setNombre(nombre);
 FILE *archivo;
 archivo=fopen("instrumentos.dat","rb+");
 fseek(archivo,sizeof obj *pos, 0);
 aux=fwrite(&obj,sizeof obj, 1, archivo);
 fclose(archivo);
system("pause");
system("cls");
return;
}

bool BajaInstrumentos(){
 Instrumentos obj;
  int ID;
  std::cout<<"ingrese la ID del instumento que quiere dar de baja: ";
  std::cin>>ID;
 int pos=buscarInstrumento(ID);
 obj=leerInstrumentos(pos);
 obj.setESTADO(false);
 FILE *archivo;
 archivo=fopen("instrumentos.dat","rb+");
 fseek(archivo,sizeof obj *pos, 0);
 bool aux= fwrite(&obj,sizeof obj, 1, archivo);
 fclose(archivo);
 return aux;
 system("pause");
 system("cls");
}


/////////////////////////////////////////////////////
void AgregarPais() {
    Paises obj;
    FILE* pCli;
    pCli = fopen("pais.dat", "ab");
    if (pCli == NULL) {
        std::cout << "NO SE PUDO CREAR EL ARCHIVO" << std::endl;
        return;
    }
    obj.AgregarPaises();
    fwrite(&obj, sizeof(Paises), 1, pCli);
    fclose(pCli);
    std::cout << "Pais agregado correctamente" << std::endl;
    system("pause");
    system("cls");
}

void ListarPaisPorID(){
 Paises obj;
  bool encontro = false;
  FILE * pCli;
  pCli = fopen("pais.dat", "rb");
  if (pCli == NULL) {
    std::cout << "NO SE PUDO ABRIR EL ARCHIVO" << std::endl;
    return;
  }
  int ID;
  std::cout << "INGRESE EL ID A BUSCAR: ";
  std::cin >> ID;

  while (fread( & obj, sizeof obj, 1, pCli) == 1) {
        if (obj.getESTADO()==true){
    if (ID == obj.getID()){
      obj.MostrarPaises();
      std::cout << std::endl;
      encontro = true;
    }
  }
  }
  if (encontro == false) {
    std::cout << "NO SE ENCONTRO ESE PAIS" << std::endl;
  }
  fclose(pCli);
system("pause");
  system("cls");
}

void ListarPaises() {
    Paises obj;
    FILE* pCli;
    pCli = fopen("pais.dat", "rb");
    if (pCli == NULL) {
        std::cout << "NO SE PUDO LEER EL ARCHIVO" << std::endl;
        return;
    }
    while (fread( & obj, sizeof obj, 1, pCli) == 1) {
        if (obj.getESTADO() != false) {
            obj.MostrarPaises();
            std::cout << std::endl;
        }
            }
    fclose(pCli);
    system("pause");
    system("cls");
}

int buscarPais (int d){
Paises obj;
int pos=0;
FILE *pCli;
pCli=fopen("pais.dat","rb");
if (pCli==NULL){std::cout<<"no se puede leer archivos";return -2;}
while(fread(&obj,sizeof obj,1,pCli)==1){
    if(obj.getID()==d){
        fclose(pCli);
        return pos;
    }
    pos++;
}
fclose(pCli);
return -1;
}

Paises leerPaises (int p){
Paises obj;
obj.setID(-2);
if(p<0){obj.setID(-3);return obj;}
FILE *ar;
ar=fopen("pais.dat","rb");
if (ar==NULL){return obj;}
fseek(ar,sizeof obj *p, 0);
int aux=fread(&obj, sizeof obj,1,ar);
fclose(ar);
if(aux==0){obj.setID(-1);}
return obj;
}

void ModificarNombreDelPais(){
    Paises obj;
  int ID;
  bool aux;
  std::cout<<"ingrese la ID del instrumento cuyo nombre desea modificar: ";
  std::cin>>ID;
 int pos=buscarPais(ID);
 obj=leerPaises(pos);
 char nombre[30];
 std::cout<<"ingrese el nuevo nombre"<<std::endl;
 std::cin>>nombre;
obj.setNombre(nombre);
 FILE *archivo;
 archivo=fopen("pais.dat","rb+");
 fseek(archivo,sizeof obj *pos, 0);
 aux=fwrite(&obj,sizeof obj, 1, archivo);
 fclose(archivo);
system("pause");
system("cls");
return;
}

bool bajaPais() {
    Paises obj;
    int ID;
    std::cout << "Ingrese la ID del pa�s que desea dar de baja: ";
    std::cin >> ID;
    int pos = buscarPais(ID);
    obj = leerPaises(pos);
    obj.setESTADO(false);
    FILE* archivo;
    archivo = fopen("pais.dat", "rb+");
    fseek(archivo, sizeof(obj) * pos, 0);
    bool aux = fwrite(&obj, sizeof(obj), 1, archivo);
    fclose(archivo);
    system("pause");
    system("cls");
    return aux;
}


/////////////////////////////////////////////////////
bool copiamusicos() {
  musicos obj;
  FILE* pCli, * pBak;
  pCli = fopen("musicos.dat", "rb");
  if (pCli == NULL) {
    std::cout << "NO SE PUDO ABRIR EL ARCHIVO DE ORIGEN" << std::endl;
    return false;
  }
  pBak = fopen("musicos.bkp", "wb");
  if (pBak == NULL) {
    std::cout << "NO SE PUDO CREAR EL ARCHIVO DE RESPALDO" << std::endl;
    fclose(pCli);
    return false;
  }

  while (fread(&obj, sizeof(obj), 1, pCli) == 1) {
    fwrite(&obj, sizeof(obj), 1, pBak);
  }
  fclose(pBak);
  std::cout << "Back-up realizado con �xito" << std::endl;
  fclose(pCli);
  system("pause");
  return true;

            /// fin de copia de seguridad

}


bool copiageneros(){
///Copiar el archivo original en el backup
            generos obj;
            FILE *pCli, *pBak;
            pCli=fopen("generos.dat", "rb");
            if(pCli==NULL){
                std::cout<<"NO SE PUDO CREAR EL ARCHIVO"<<std::endl;
                return false;
            }
            pBak=fopen("generos.bkp", "wb");
            if(pBak==NULL){
               std::cout<<"NO SE PUDO CREAR EL ARCHIVO"<<std::endl;
                fclose(pCli);
                return false;
            }

            while(fread(&obj, sizeof obj, 1, pCli)==1){
                fwrite(&obj, sizeof obj, 1, pBak);
            }
            fclose(pBak);
            std::cout<<"Back-up realizado con exito"<<std::endl;
            fclose(pCli);
            system("pause");
            return true;
            /// fin de copia de seguridad
}

bool copiainstrumentos(){
            Instrumentos obj;
            FILE *pCli, *pBak;
            pCli=fopen("instrumentos.dat", "rb");
            if(pCli==NULL){
                std::cout<<"NO SE PUDO CREAR EL ARCHIVO"<<std::endl;
                return false;
            }
            pBak=fopen("instrumentos.bkp", "wb");
            if(pBak==NULL){
               std::cout<<"NO SE PUDO CREAR EL ARCHIVO"<<std::endl;
                fclose(pCli);
                return false;
            }

            while(fread(&obj, sizeof obj, 1, pCli)==1){
                fwrite(&obj, sizeof obj, 1, pBak);
            }
            fclose(pBak);
            std::cout<<"Back-up realizado con exito"<<std::endl;
            fclose(pCli);
            system("pause");
            return true;
            /// fin de copia de seguridad
}

bool copiapaises(){
            Paises obj;
            FILE *pCli, *pBak;
            pCli=fopen("pais.dat", "rb");
            if(pCli==NULL){
                std::cout<<"NO SE PUDO CREAR EL ARCHIVO"<<std::endl;
                return false;
            }
            pBak=fopen("pais.bkp", "wb");
            if(pBak==NULL){
               std::cout<<"NO SE PUDO CREAR EL ARCHIVO"<<std::endl;
                fclose(pCli);
                return false;
            }

            while(fread(&obj, sizeof obj, 1, pCli)==1){
                fwrite(&obj, sizeof obj, 1, pBak);
            }
            fclose(pBak);
            std::cout<<"Back-up realizado con exito"<<std::endl;
            fclose(pCli);
            system("pause");
            return true;
            /// fin de copia de seguridad
}



void restauraMusicos(){
            system("cls");
  musicos obj;
            FILE *pCli, *pBak;
            pCli=fopen("musicos.bkp", "rb");
            if(pCli==NULL){
                std::cout<<"NO SE PUDO CREAR EL ARCHIVO"<<std::endl;
                return;
            }
            pBak=fopen("musicos.dat", "wb");
            if(pBak==NULL){
               std::cout<<"NO SE PUDO CREAR EL ARCHIVO"<<std::endl;
                fclose(pCli);
                return;
            }

            while(fread(&obj, sizeof obj, 1, pCli)==1){
                fwrite(&obj, sizeof obj, 1, pBak);
            }
            fclose(pBak);
            std::cout<<"Se han restaurado exitosamente los registros"<<std::endl;
            fclose(pCli);
             system("pause");

}


void restauraGeneros(){
            system("cls");
            generos obj;
            FILE *pCli, *pBak;
            pCli=fopen("generos.bkp", "rb");
            if(pCli==NULL){
                std::cout<<"NO SE PUDO CREAR EL ARCHIVO"<<std::endl;
                return;
            }
            pBak=fopen("generos.dat", "wb");
            if(pBak==NULL){
               std::cout<<"NO SE PUDO CREAR EL ARCHIVO"<<std::endl;
                fclose(pCli);
                return;
            }

            while(fread(&obj, sizeof obj, 1, pCli)==1){
                fwrite(&obj, sizeof obj, 1, pBak);
            }
            fclose(pBak);
            std::cout<<"Se han restaurado exitosamente los registros"<<std::endl;
            fclose(pCli);
            system("pause");
}

void restauraInstrumentos(){
            system("cls");
            Instrumentos obj;
            FILE *pCli, *pBak;
            pCli=fopen("instrumentos.bkp", "rb");
            if(pCli==NULL){
                std::cout<<"NO SE PUDO CREAR EL ARCHIVO"<<std::endl;
                return;
            }
            pBak=fopen("instrumentos.dat", "wb");
            if(pBak==NULL){
               std::cout<<"NO SE PUDO CREAR EL ARCHIVO"<<std::endl;
                fclose(pCli);
                return;
            }

            while(fread(&obj, sizeof obj, 1, pCli)==1){
                fwrite(&obj, sizeof obj, 1, pBak);
            }
            fclose(pBak);
            std::cout<<"Se han restaurado exitosamente los registros"<<std::endl;
            fclose(pCli);
            system("pause");
}


void restauraPaises(){
            system("cls");
            generos obj;
            FILE *pCli, *pBak;
            pCli=fopen("pais.bkp", "rb");
            if(pCli==NULL){
                std::cout<<"NO SE PUDO CREAR EL ARCHIVO"<<std::endl;
                return;
            }
            pBak=fopen("pais.dat", "wb");
            if(pBak==NULL){
               std::cout<<"NO SE PUDO CREAR EL ARCHIVO"<<std::endl;
                fclose(pCli);
                return;
            }

            while(fread(&obj, sizeof obj, 1, pCli)==1){
                fwrite(&obj, sizeof obj, 1, pBak);
            }
            fclose(pBak);
            std::cout<<"Se han restaurado exitosamente los registros"<<std::endl;
            fclose(pCli);
            system("pause");
}

void entradadefaultMusicos(){

  musicos obj;
  FILE * pCli;
  pCli = fopen("musdefault.dat", "ab");
  if (pCli == NULL) {
    std::cout << "NO SE PUDO CREAR EL ARCHIVO" << std::endl;
  }
  obj.cargarmusicos();
  fwrite( & obj, sizeof(musicos), 1, pCli);
  fclose(pCli);
  system("pause");
  system("cls");
}


void entradaDefaultGeneros(){
  generos obj;
  FILE * pCli;
  pCli = fopen("gendefault.dat", "ab");
  if (pCli == NULL) {
    std::cout << "NO SE PUDO CREAR EL ARCHIVO" << std::endl;
  }
  obj.agregarGenero();
  fwrite( & obj, sizeof(generos), 1, pCli);
  fclose(pCli);
  system("pause");
  system("cls");
}

void entradaDefaultInstrumentos(){
  Instrumentos obj;
  FILE * pCli;
  pCli = fopen("insdefault.dat", "ab");
  if (pCli == NULL) {
    std::cout << "NO SE PUDO CREAR EL ARCHIVO" << std::endl;
  }
  obj.AgregarInstrumento();
  fwrite( & obj, sizeof(Instrumentos), 1, pCli);
  fclose(pCli);
  system("pause");
  system("cls");
}

void entradaDefaultPaises(){
  Paises obj;
  FILE * pCli;
  pCli = fopen("paisdefault.dat", "ab");
  if (pCli == NULL) {
    std::cout << "NO SE PUDO CREAR EL ARCHIVO" << std::endl;
  }
  obj.AgregarPaises();
  fwrite( & obj, sizeof(Paises), 1, pCli);
  fclose(pCli);
  system("pause");
  system("cls");
}


void mostrarDefaultMus(){
musicos obj;
  FILE * pCli;
  pCli = fopen("musdefault.dat", "rb");
  if (pCli == NULL) {
    std::cout << "NO SE PUDO LEER EL ARCHIVO" << std::endl;
    return;
  }

  while (fread( & obj, sizeof obj, 1, pCli) == 1) {
    obj.mostrarmusicos();
    std::cout << std::endl;
  }
  fclose(pCli);
  system("pause");
  system("cls");
}


void mostrarDefaultGen(){
generos obj;
  FILE * pCli;
  pCli = fopen("gendefault.dat", "rb");
  if (pCli == NULL) {
    std::cout << "NO SE PUDO LEER EL ARCHIVO" << std::endl;
    return;
  }

  while (fread( & obj, sizeof obj, 1, pCli) == 1) {
        if(obj.getESTADO()!=false){
    obj.mostrarGeneros();
    std::cout << std::endl;
  }
  }
  fclose(pCli);
}

void mostrarDefaultIns(){
Instrumentos obj;
  FILE * pCli;
  pCli = fopen("insdefault.dat", "rb");
  if (pCli == NULL) {
    std::cout << "NO SE PUDO LEER EL ARCHIVO" << std::endl;
    return;
  }

  while (fread( & obj, sizeof obj, 1, pCli) == 1) {
        if(obj.getESTADO()!=false){
    obj.MostrarInstrumentos();
    std::cout << std::endl;
  }
  }
  fclose(pCli);
}

void mostrarDefaultPais(){
Paises obj;
  FILE * pCli;
  pCli = fopen("paisdefault.dat", "rb");
  if (pCli == NULL) {
    std::cout << "NO SE PUDO LEER EL ARCHIVO" << std::endl;
    return;
  }

  while (fread( & obj, sizeof obj, 1, pCli) == 1) {
        if(obj.getESTADO()!=false){
    obj.MostrarPaises();
    std::cout << std::endl;
  }
  }
  fclose(pCli);
}


void datosDefault(){
            ///MUSICOS
            musicos obj;
            FILE *pCli, *pBak;
            pCli=fopen("musdefault.dat", "rb");
            if(pCli==NULL){
                std::cout<<"NO SE PUDO CREAR EL ARCHIVO"<<std::endl;
                return;
            }
            pBak=fopen("musicos.dat", "wb");
            if(pBak==NULL){
               std::cout<<"NO SE PUDO CREAR EL ARCHIVO"<<std::endl;
                fclose(pCli);
                return;
            }

            while(fread(&obj, sizeof obj, 1, pCli)==1){
                fwrite(&obj, sizeof obj, 1, pBak);
            }
            fclose(pBak);
            std::cout<<"Se han establecido los datos por defecto de los musicos con exito"<<std::endl;
            fclose(pCli);



            ///GENEROS
            generos objg;
            FILE *pGen, *pBakG;
            pGen=fopen("gendefault.dat", "rb");
            if(pGen==NULL){
                std::cout<<"NO SE PUDO CREAR EL ARCHIVO"<<std::endl;
                return;
            }
            pBakG=fopen("generos.dat", "wb");
            if(pBakG==NULL){
               std::cout<<"NO SE PUDO CREAR EL ARCHIVO"<<std::endl;
                fclose(pGen);
                return;
            }

            while(fread(&objg, sizeof objg, 1, pGen)==1){
                fwrite(&objg, sizeof objg, 1, pBakG);
            }
            fclose(pBakG);
            std::cout<<"Se han establecido los datos por defecto de los generos con exito"<<std::endl;
            fclose(pGen);


            ///INSTRUMENTOS

                        Instrumentos reg;
            FILE *pIns, *pBakI;
            pIns=fopen("insdefault.dat", "rb");
            if(pIns==NULL){
                std::cout<<"NO SE PUDO CREAR EL ARCHIVO"<<std::endl;
                return;
            }
            pBakI=fopen("instrumentos.dat", "wb");
            if(pBakI==NULL){
               std::cout<<"NO SE PUDO CREAR EL ARCHIVO"<<std::endl;
                fclose(pIns);
                return;
            }

            while(fread(&reg, sizeof reg, 1, pIns)==1){
                fwrite(&reg, sizeof reg, 1, pBakI);
            }
            fclose(pBakI);
            std::cout<<"Se han establecido los datos por defecto de los instrumentos con exito"<<std::endl;
            fclose(pIns);



            ///PAISES
                                    Paises regx;
            FILE *pPai, *pBakP;
            pPai=fopen("paisdefault.dat", "rb");
            if(pPai==NULL){
                std::cout<<"NO SE PUDO CREAR EL ARCHIVO"<<std::endl;
                return;
            }
            pBakP=fopen("pais.dat", "wb");
            if(pBakP==NULL){
               std::cout<<"NO SE PUDO CREAR EL ARCHIVO"<<std::endl;
                fclose(pPai);
                return;
            }

            while(fread(&regx, sizeof regx, 1, pPai)==1){
                fwrite(&regx, sizeof regx, 1, pBakP);
            }
            fclose(pBakP);
            std::cout<<"Se han establecido los datos por defecto de los paises con exito"<<std::endl;
            fclose(pPai);
            system("pause");
            /// fin de copia de seguridad
}







#endif // FUNCIONES_GLOBALES_H_INCLUDED
